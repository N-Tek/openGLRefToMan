<html>
<head>
<title>OpenGL ES SDK</title>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/opengles/sdk/inc/sdk_head.txt"); ?>
</head>
<body>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/opengles/sdk/inc/sdk_body_start.txt"); ?>
<?php include($_SERVER['DOCUMENT_ROOT'] . "/opengles/sdk/inc/sdk_footer.txt"); ?>
</body>
</html>
